import time

print("Plese insert your card : ")

time.sleep(5)

password=1234
pin=int(input("enter your ATM pin : "))
balance=5000

if pin==password:
    while True:
        print("""
        1 == Transactions History
        2 == Withdraw
        3 == Deposit
        4 == Transfer
        5 == Quit
          """
        )
        try:
            option=int(input("Please enter yor choise : "))
        except:
            print("Please enter valid Option ")
            continue

        if option==1:
            print(f"your current balence is {balance}")
            print("=============================================")


        if option==2:
            withdraw_amount=int(input("please enter withdraw amount : "))
            if withdraw_amount <=balance:
                balance=balance-withdraw_amount
                print(f"{withdraw_amount} is debited from your account")
                print(f"your curent balence is {balance}")
                print("=============================================")
            else:
                print("insufficient amount in your account")

        if option==3:
            deposit_amount=int(input("Please enter deposit Amount : "))
            balance=balance+deposit_amount
            print(f"{deposit_amount} is creadited to your account")
            print(f"Your updated amount is {balance}")
            print("=============================================")

        if option==4:
            person_Id=int(input("Enter Account Number : "))
            Transfer_ammount=int(input("Enter the Amount to transfer : "))
            balance=balance-Transfer_ammount
            print(f"{Transfer_ammount} is Transferd to {person_Id} account Successfully")
            print(f"Your updated amount is {balance}")
        if option==5:
            break


else: 
    print("Wrong pin Please try again")